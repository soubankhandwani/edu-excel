<?php 
//print_r($_POST);
$output = file_get_contents('../mail_templates/contact.html'); 
if ($output === false) {
    echo "Error reading the 'contact.html' file: " . error_get_last()['message'];
    exit;
}

$output2 = file_get_contents('../mail_templates/thankyou.html'); 
if ($output2 === false) {
    echo "Error reading the 'thankyou.html' file: " . error_get_last()['message'];
    exit;
}
$output = str_replace('%username%', $_POST['name'], $output); 
$output = str_replace('%useremail%', $_POST['email'], $output); 
$output = str_replace('%phone%', $_POST['phone'], $output); 
$output = str_replace('%subject%', $_POST['subject'], $output);
$output = str_replace('%message%', $_POST['message'], $output); 
//exit();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require_once "../vendor/autoload.php"; //PHPMailer Object 
$mail = new PHPMailer(); //From email address and name 
$mail->isSMTP();
//$mail->SMTPDebug = 2;
$mail->Host = 'mail.maaadvertising.co.in';
$mail->SMTPAuth = true;
$mail->Username = 'support@maaadvertising.co.in';
$mail->Password = '1PmDy0X8';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;
$mail->From = "support@maaadvertising.co.in"; 
$mail->FromName = "Maa Advertising"; //To address and name 
$mail->addAddress($_POST['email']);//Recipient name is optional
//$mail->addAddress("support@maaadvertising.co.in");

$mail->isHTML(true);
$mail->CharSet="utf-8"; 
$mail->Subject = "Enquiry Email"; 
$mail->MsgHTML($output);
//$mail->Body = "tets";
//$mail->AltBody = "This is the plain text version of the email content";
// print_r($output);
// exit(); 
if(!$mail->send()) 
{
    // echo '<pre>';
    // print_r($mail);
//echo "Mailer Error: " . $mail->ErrorInfo; 
  header('Content-Type: application/json');
  echo json_encode(array('message' => "Failed to send mail. Please contact site admin.", 'status' => 500));
} 
else { 
  //echo "Message has been sent successfully";
  //$_SESSION['success_msg'] =  "Message has been sent successfully"; 
  //header("location: https://maaadvertising.co.in");
  header('Content-Type: application/json');
  echo json_encode(array('message' => "Message has been sent successfully", 'status' => 200));
}



$mail->addAddress("support@maaadvertising.co.in");

$mail->isHTML(true);
$mail->CharSet="utf-8"; 
$mail->Subject = "Enquiry Email"; 
$mail->MsgHTML($output2);

if(!$mail->send()) 
{
  //header('Content-Type: application/json');
  //echo json_encode(array('message' => "Failed to send mail. Please contact site admin.", 'status' => 500));
} 
else { 
  //header('Content-Type: application/json');
  //echo json_encode(array('message' => "Message has been sent successfully", 'status' => 200));
}
?>